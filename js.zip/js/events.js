(()=>{const __name=(target)=>target;((w, version, schemaVersions, maxEventsPerBatch = 50, maxBatchBodyBytes = 50 * 1024, maxReplayBodyBytes = 512 * 1024, maxReplayEventsPerChunk = 100, maxReplayTotalBytes = 5 * 1024 * 1024, maxReplayChunks = 50, maxReplayDurationMs = 10 * 60 * 1e3, replayFlushIntervalMs = 2e3) => {
  const existing = w.__lovableEvents || {};
  if (existing.__userAppEventsSdkVersion) return;
  const d = w.document;
  const nav = w.navigator || {};
  const automated = nav.webdriver === true || !!w.Cypress || !!w.__nightmare;
  const perf = w.performance || { now: /* @__PURE__ */ __name(() => Date.now(), "now") };
  const loc = w.location || { pathname: "", href: "", search: "" };
  const resolveSetTimer = /* @__PURE__ */ __name(() => w.setTimeout || (typeof setTimeout === "function" ? setTimeout : null), "resolveSetTimer");
  const resolveClearTimer = /* @__PURE__ */ __name(() => w.clearTimeout || (typeof clearTimeout === "function" ? clearTimeout : null), "resolveClearTimer");
  const isInternalPath = /* @__PURE__ */ __name((path) => path === "/__codex_token_check" || path.startsWith("/__l5e/"), "isInternalPath");
  if (isInternalPath(loc.pathname)) return;
  const script = d && d.currentScript;
  const artifact = script ? {
    kind: script.getAttribute("data-artifact-kind") || null,
    id: script.getAttribute("data-artifact-id") || null,
    commit_sha: script.getAttribute("data-commit-sha") || null,
    context_token: script.getAttribute("data-context-token") || null
  } : {};
  const replayMode = script?.getAttribute("data-replay") || null;
  const trackUrl = script?.getAttribute("data-track-url") || "/__l5e/trackevents";
  const replayUrl = script?.getAttribute("data-replay-url") || "/__l5e/replay";
  const replayScriptUrl = script?.getAttribute("data-replay-script-url") || "/__l5e/rrweb-record.js";
  const parseSampleRate = /* @__PURE__ */ __name((value) => {
    const rate = typeof value === "string" ? Number(value) : 0;
    if (!Number.isFinite(rate) || rate <= 0) return 0;
    return rate >= 1 ? 1 : rate;
  }, "parseSampleRate");
  const replaySampleRate = parseSampleRate(script?.getAttribute("data-replay-sample-rate") || null);
  const replayCrashSampleRate = parseSampleRate(script?.getAttribute("data-replay-crash-sample-rate") || null);
  const autocaptureEnabled = script?.getAttribute("data-autocapture") === "1";
  const randomBytes = /* @__PURE__ */ __name((byteCount) => {
    const bytes = new Uint8Array(byteCount);
    if (w.crypto && typeof w.crypto.getRandomValues === "function") {
      w.crypto.getRandomValues(bytes);
    } else {
      for (let index = 0; index < bytes.length; index++) {
        bytes[index] = Math.floor(Math.random() * 256);
      }
    }
    return bytes;
  }, "randomBytes");
  const toHex = /* @__PURE__ */ __name((bytes) => Array.from(bytes, (byte) => byte.toString(16).padStart(2, "0")).join(""), "toHex");
  const randomUuid = /* @__PURE__ */ __name(() => {
    if (w.crypto && typeof w.crypto.randomUUID === "function") return w.crypto.randomUUID();
    const bytes = randomBytes(16);
    bytes[6] = bytes[6] & 15 | 64;
    bytes[8] = bytes[8] & 63 | 128;
    const hex = toHex(bytes);
    return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
  }, "randomUuid");
  const randomTraceHex = /* @__PURE__ */ __name((byteCount) => {
    const bytes = randomBytes(byteCount);
    if (bytes.every((byte) => byte === 0)) bytes[bytes.length - 1] = 1;
    return toHex(bytes);
  }, "randomTraceHex");
  const createTraceContext = /* @__PURE__ */ __name(() => ({
    traceId: randomTraceHex(16),
    rootSpanId: randomTraceHex(8)
  }), "createTraceContext");
  const sessionId = randomUuid();
  let appUserId = null;
  let pageViewId = randomUuid();
  let capturedClicks = 0;
  let traceContext = createTraceContext();
  let engagementAccruedMs = 0;
  let engagementSegmentStart = null;
  const ENGAGEMENT_EMIT_DELAYS_MS = [1e4, 3e4, 6e4, 3e5];
  let engagementEmitStep = 0;
  let engagementTimer = null;
  const ENGAGEMENT_ACCRUAL_STOP_MS = 144e5;
  let engagementReportedMs = 0;
  let engagementCapped = false;
  const ENGAGEMENT_UNFOCUSED_GRACE_MS = 18e5;
  let engagementUnfocusedTimer = null;
  let engagementUnfocusedSpentMs = 0;
  let engagementUnfocusedArmedAt = 0;
  let engagementStoppedUnfocused = false;
  const unitIntervalFor = /* @__PURE__ */ __name((value) => {
    let hash = 2166136261;
    for (let index = 0; index < value.length; index++) {
      hash ^= value.charCodeAt(index);
      hash = Math.imul(hash, 16777619);
    }
    return (hash >>> 0) / 4294967296;
  }, "unitIntervalFor");
  const replaySamplingValue = unitIntervalFor(sessionId);
  const isReplaySampledIn = replaySampleRate > 0 && replaySamplingValue < replaySampleRate;
  const isReplayCrashSampledIn = replayCrashSampleRate > 0 && replaySamplingValue < replayCrashSampleRate;
  const isReplayRecordingAllowed = isReplaySampledIn || isReplayCrashSampledIn;
  const replayEffectiveSampleRate = isReplaySampledIn ? replaySampleRate : replayCrashSampleRate;
  let replayId = null;
  let replayEventCount = 0;
  let replayStartedAt = 0;
  let replayFinalized = false;
  let stopReplayRecorder = null;
  let replayChunkSequence = 0;
  let replayThrottledChunks = 0;
  let replayChunksInFlight = 0;
  let replayBudgetStopReason = null;
  let replayUploadedBytes = 0;
  let replayFlushTimer = null;
  let replayDurationTimer = null;
  let replayRecorderActive = false;
  let replayRecorderLoading = false;
  let replayHasFullSnapshot = false;
  let replayUploadEnabled = isReplaySampledIn;
  let replayCaptureReason = isReplaySampledIn ? "sampled" : null;
  let replayTriggerEventId = null;
  let replayTriggerEventName = null;
  let replayCaptureMetadataEmitted = false;
  const replayQueue = [];
  const maxReplayBufferedEvents = Math.max(maxReplayEventsPerChunk, maxReplayEventsPerChunk * maxReplayChunks);
  const replayMaskTextSelector = [
    "[data-lovable-mask]",
    "[data-sensitive]",
    "[data-private]",
    "[data-auth]",
    "[data-payment]",
    "[contenteditable]",
    "[autocomplete]",
    "[name*='email' i]",
    "[name*='phone' i]",
    "[name*='address' i]",
    "[name*='token' i]",
    "[name*='secret' i]"
  ].join(",");
  const replayBlockSelector = [
    "canvas",
    "embed",
    "iframe",
    "object",
    "video",
    "[data-lovable-block]",
    ".rr-block",
    "[data-payment]",
    "[data-auth]",
    "[data-private]"
  ].join(",");
  const replayIgnoreSelector = "[data-lovable-ignore],.rrweb-ignore";
  const maskReplayText = /* @__PURE__ */ __name((text) => text.replace(/[^\s]/gu, "*"), "maskReplayText");
  const queue = [];
  let flushTimer = null;
  let sendingDisabled = false;
  let sendRejectionReported = false;
  let sendDisabledReported = false;
  let unloadingPage = false;
  let immediateErrorFlushes = 0;
  let errorEventsSeen = 0;
  const batchSize = Math.max(1, maxEventsPerBatch);
  const maxImmediateErrorFlushes = 5;
  const maxErrorEventsPerPageLoad = 200;
  const projectEventNamePattern = /^project\.[a-z][a-z0-9_]{0,63}(\.[a-z][a-z0-9_]{0,63})*$/u;
  const schemaVersionFor = /* @__PURE__ */ __name((eventName) => {
    const schemaVersion = schemaVersions[eventName];
    if (typeof schemaVersion === "number" && schemaVersion > 0) return schemaVersion;
    return projectEventNamePattern.test(eventName) ? 1 : null;
  }, "schemaVersionFor");
  const textEncoder = typeof TextEncoder === "function" ? new TextEncoder() : null;
  const byteLength = /* @__PURE__ */ __name((value) => textEncoder ? textEncoder.encode(value).length : value.length, "byteLength");
  const createBatchBody = /* @__PURE__ */ __name((events) => JSON.stringify({
    envelope_schema_version: 1,
    batch_id: randomUuid(),
    sent_at: (/* @__PURE__ */ new Date()).toISOString(),
    sdk: { name: "lovable-user-app-events", version },
    automated,
    artifact,
    events
  }), "createBatchBody");
  const report2 = /* @__PURE__ */ __name((message3) => {
    const consoleRef = w.console;
    if (consoleRef && typeof consoleRef.debug === "function") consoleRef.debug(`[lovable-analytics] ${message3}`);
  }, "report");
  const applyRejectedBatchStatus = /* @__PURE__ */ __name((status, routeMarker) => {
    if ((status === 403 || status === 404) && routeMarker === "rejected") {
      sendingDisabled = true;
      queue.length = 0;
      if (!sendDisabledReported) {
        sendDisabledReported = true;
        report2(`events disabled for this page load (HTTP ${status})`);
      }
      return;
    }
    if (sendRejectionReported) return;
    sendRejectionReported = true;
    report2(`event batch rejected (HTTP ${status})`);
  }, "applyRejectedBatchStatus");
  const keepalivePoolBytes = 64 * 1024;
  const eventsKeepaliveReserveBytes = 16 * 1024;
  let keepaliveBytesInFlight = 0;
  let beaconBytesInFlight = 0;
  const releaseBeaconBytes = /* @__PURE__ */ __name(() => {
    keepaliveBytesInFlight -= beaconBytesInFlight;
    beaconBytesInFlight = 0;
  }, "releaseBeaconBytes");
  const send = /* @__PURE__ */ __name((url, body, options) => {
    const bodyBytes = byteLength(body);
    const keepaliveLimitBytes = keepalivePoolBytes - (options.reserveBytes || 0);
    const allowKeepalive = !!options.keepalive && keepaliveBytesInFlight + bodyBytes <= keepaliveLimitBytes;
    if (allowKeepalive) keepaliveBytesInFlight += bodyBytes;
    let charged = allowKeepalive;
    const release = /* @__PURE__ */ __name(() => {
      if (!charged) return;
      charged = false;
      keepaliveBytesInFlight -= bodyBytes;
    }, "release");
    const BlobCtor = w.Blob || (typeof Blob === "function" ? Blob : null);
    if (allowKeepalive && options.beacon && nav.sendBeacon && BlobCtor) {
      try {
        const ok = nav.sendBeacon(url, new BlobCtor([body], { type: "application/json" }));
        if (ok) {
          beaconBytesInFlight += bodyBytes;
          charged = false;
          return;
        }
      } catch {
      }
    }
    const fetchFn = w.fetch || (typeof fetch === "function" ? fetch : null);
    if (!fetchFn) {
      release();
      options.onNetworkError?.();
      return;
    }
    try {
      Promise.resolve(
        fetchFn(url, {
          method: "POST",
          headers: { "content-type": "application/json" },
          body,
          ...allowKeepalive ? { keepalive: true } : {}
        })
      ).then(
        (response) => {
          release();
          options.onResponse?.(response);
        },
        () => {
          release();
          options.onNetworkError?.();
        }
      ).catch(() => {
      });
    } catch {
      release();
      options.onNetworkError?.();
    }
  }, "send");
  const sendBatch = /* @__PURE__ */ __name((allEvents, unloading) => {
    const events = allEvents.filter((event) => {
      try {
        JSON.stringify(event);
        return true;
      } catch {
        return false;
      }
    });
    let start = 0;
    while (start < events.length) {
      let end = events.length;
      let body = createBatchBody(events.slice(start, end));
      const remaining = keepalivePoolBytes - keepaliveBytesInFlight;
      const splitLimit = unloading && remaining >= eventsKeepaliveReserveBytes ? Math.min(maxBatchBodyBytes, remaining) : maxBatchBodyBytes;
      while (end - start > 1 && byteLength(body) > splitLimit) {
        end = start + Math.max(1, Math.floor((end - start) / 2));
        body = createBatchBody(events.slice(start, end));
      }
      send(trackUrl, body, {
        keepalive: true,
        beacon: unloading,
        onResponse: /* @__PURE__ */ __name((response) => {
          if (!response || response.ok !== false) return;
          applyRejectedBatchStatus(response.status, response.headers?.get?.("x-lovable-events") ?? null);
        }, "onResponse")
      });
      start = end;
    }
  }, "sendBatch");
  const createReplayChunkBody = /* @__PURE__ */ __name((events, chunkID, chunkSequence) => {
    if (!replayId) return null;
    return JSON.stringify({
      envelope_schema_version: 1,
      replay_schema_version: 1,
      replay_id: replayId,
      chunk_id: chunkID,
      chunk_sequence: chunkSequence,
      sent_at: (/* @__PURE__ */ new Date()).toISOString(),
      sdk: { name: "lovable-user-app-events", version },
      automated,
      artifact,
      session_id: sessionId,
      page_view_id: pageViewId,
      events
    });
  }, "createReplayChunkBody");
  const canSendReplayEvent = /* @__PURE__ */ __name((event) => {
    const body = createReplayChunkBody([event], "00000000-0000-4000-8000-000000000000", replayChunkSequence);
    return !!body && byteLength(body) <= maxReplayBodyBytes;
  }, "canSendReplayEvent");
  const replayEventType = /* @__PURE__ */ __name((event) => {
    const record = event && typeof event === "object" ? event : null;
    return typeof record?.type === "number" ? record.type : null;
  }, "replayEventType");
  const replayDurationMs = /* @__PURE__ */ __name(() => Math.max(0, perf.now() - replayStartedAt), "replayDurationMs");
  const clearReplayFlushTimer = /* @__PURE__ */ __name(() => {
    if (!replayFlushTimer) return;
    const clearTimer = resolveClearTimer();
    if (clearTimer) clearTimer(replayFlushTimer);
    replayFlushTimer = null;
  }, "clearReplayFlushTimer");
  const clearReplayDurationTimer = /* @__PURE__ */ __name(() => {
    if (!replayDurationTimer) return;
    const clearTimer = resolveClearTimer();
    if (clearTimer) clearTimer(replayDurationTimer);
    replayDurationTimer = null;
  }, "clearReplayDurationTimer");
  const stopReplayRecorderSafely = /* @__PURE__ */ __name(() => {
    try {
      stopReplayRecorder?.();
    } catch {
    } finally {
      stopReplayRecorder = null;
      replayRecorderActive = false;
    }
  }, "stopReplayRecorderSafely");
  const replayErrorStageFor = /* @__PURE__ */ __name((reason) => {
    switch (reason) {
      case "recorder_script_failed":
        return "recorder_script";
      case "recorder_start_failed":
        return "recorder_start";
      case "recorder_runtime_error":
        return "recorder_runtime";
      case "missing_full_snapshot":
      case "full_snapshot_too_large":
        return "snapshot";
      case "upload_failed":
        return "upload";
      default:
        return null;
    }
  }, "replayErrorStageFor");
  const emitReplayErrorFor = /* @__PURE__ */ __name((targetReplayId, reason, eventCount, durationMs, chunkCount, uploadedBytes) => {
    const stage = replayErrorStageFor(reason);
    if (!stage) return;
    enqueue("lovable.replay_error", {
      replay_id: targetReplayId,
      reason,
      stage,
      recorder: "rrweb",
      sample_rate: replayEffectiveSampleRate,
      event_count: eventCount,
      duration_ms: durationMs,
      chunk_count: chunkCount,
      uploaded_bytes: uploadedBytes
    });
  }, "emitReplayErrorFor");
  const replayCaptureProperties = /* @__PURE__ */ __name(() => !replayCaptureReason || replayCaptureReason === "sampled" ? {} : {
    capture_reason: replayCaptureReason,
    trigger_event_id: replayTriggerEventId,
    trigger_event_name: replayTriggerEventName
  }, "replayCaptureProperties");
  const emitReplayMetadataFor = /* @__PURE__ */ __name((targetReplayId, status, reason, eventCount, durationMs, chunkCount, uploadedBytes) => {
    enqueue("lovable.session_replay", {
      replay_id: targetReplayId,
      status,
      reason,
      recorder: "rrweb",
      sample_rate: replayEffectiveSampleRate,
      event_count: eventCount,
      duration_ms: durationMs,
      chunk_count: chunkCount,
      uploaded_bytes: uploadedBytes,
      ...replayCaptureProperties()
    });
    emitReplayErrorFor(targetReplayId, reason, eventCount, durationMs, chunkCount, uploadedBytes);
  }, "emitReplayMetadataFor");
  const emitReplayMetadata = /* @__PURE__ */ __name((status, reason) => {
    if (!replayId) return;
    emitReplayMetadataFor(
      replayId,
      status,
      reason,
      replayEventCount,
      replayDurationMs(),
      replayChunkSequence,
      replayUploadedBytes
    );
  }, "emitReplayMetadata");
  const shouldEmitReplayLifecycleMetadata = /* @__PURE__ */ __name(() => replayUploadEnabled || replayCaptureReason === "sampled", "shouldEmitReplayLifecycleMetadata");
  const emitReplayMetadataOrErrorFor = /* @__PURE__ */ __name((targetReplayId, status, reason, eventCount, durationMs, chunkCount, uploadedBytes) => {
    if (shouldEmitReplayLifecycleMetadata()) {
      emitReplayMetadataFor(targetReplayId, status, reason, eventCount, durationMs, chunkCount, uploadedBytes);
    } else {
      emitReplayErrorFor(targetReplayId, reason, eventCount, durationMs, chunkCount, uploadedBytes);
    }
  }, "emitReplayMetadataOrErrorFor");
  const stopReplayRecording = /* @__PURE__ */ __name((reason, dropQueuedEvents = false) => {
    if (!replayId || replayFinalized) return;
    stopReplayRecorderSafely();
    clearReplayDurationTimer();
    if (dropQueuedEvents) {
      replayQueue.length = 0;
      clearReplayFlushTimer();
    }
    if (shouldEmitReplayLifecycleMetadata()) {
      emitReplayMetadata("stopped", reason);
    }
    replayFinalized = true;
  }, "stopReplayRecording");
  const stopReplayAtDurationLimit = /* @__PURE__ */ __name(() => {
    if (!replayId || replayFinalized) return;
    if (!replayUploadEnabled) {
      stopReplayRecorderSafely();
      clearReplayDurationTimer();
      return;
    }
    stopReplayRecording("duration_limit", true);
  }, "stopReplayAtDurationLimit");
  const markReplayCapturedByClientError = /* @__PURE__ */ __name((triggerEventId) => {
    if (!replayId || replayFinalized || replayCaptureReason === "client_error") return;
    replayUploadEnabled = true;
    replayCaptureReason = "client_error";
    replayTriggerEventId = triggerEventId;
    replayTriggerEventName = "lovable.client_error";
    emitReplayCaptureMetadataIfReady();
  }, "markReplayCapturedByClientError");
  const hasReplayDataToCapture = /* @__PURE__ */ __name(() => replayQueue.length > 0 || replayChunkSequence > 0 || replayUploadedBytes > 0, "hasReplayDataToCapture");
  const emitReplayCaptureMetadataIfReady = /* @__PURE__ */ __name(() => {
    if (!replayId || replayFinalized || replayCaptureReason !== "client_error" || replayCaptureMetadataEmitted || !replayHasFullSnapshot || !hasReplayDataToCapture()) {
      return false;
    }
    replayCaptureMetadataEmitted = true;
    emitReplayMetadata("captured", "client_error");
    flushReplay(true);
    return true;
  }, "emitReplayCaptureMetadataIfReady");
  const endReplayOnSpentBudget = /* @__PURE__ */ __name((reason) => {
    if (replayChunksInFlight > 0) {
      replayBudgetStopReason = reason;
      return;
    }
    stopReplayRecording(reason, true);
  }, "endReplayOnSpentBudget");
  const settleReplayChunk = /* @__PURE__ */ __name(() => {
    replayChunksInFlight--;
    if (replayFinalized || replayChunksInFlight > 0 || !replayBudgetStopReason) return;
    const reason = replayBudgetStopReason;
    replayBudgetStopReason = null;
    if (replayThrottledChunks > 0) scheduleReplayFlush();
    else stopReplayRecording(reason, true);
  }, "settleReplayChunk");
  const flushReplay = /* @__PURE__ */ __name((preferKeepalive = false) => {
    clearReplayFlushTimer();
    if (!replayUploadEnabled || !replayId || replayQueue.length === 0 || !replayHasFullSnapshot) return;
    while (!replayFinalized && replayQueue.length > 0) {
      let count2 = Math.min(replayQueue.length, maxReplayEventsPerChunk);
      const chunkID = randomUuid();
      const chunkSequence = replayChunkSequence;
      let body = createReplayChunkBody(replayQueue.slice(0, count2), chunkID, chunkSequence);
      while (body && count2 > 1 && byteLength(body) > maxReplayBodyBytes) {
        count2 = Math.max(1, Math.floor(count2 / 2));
        body = createReplayChunkBody(replayQueue.slice(0, count2), chunkID, chunkSequence);
      }
      if (!body) return;
      const bodyBytes = byteLength(body);
      if (bodyBytes > maxReplayBodyBytes) {
        replayQueue.shift();
        replayEventCount = Math.max(0, replayEventCount - 1);
        continue;
      }
      const chunksStored = replayChunkSequence - replayThrottledChunks;
      if (chunksStored >= maxReplayChunks || replayUploadedBytes + bodyBytes > maxReplayTotalBytes) {
        endReplayOnSpentBudget(chunksStored >= maxReplayChunks ? "chunk_limit" : "size_limit");
        return;
      }
      replayQueue.splice(0, count2);
      replayChunkSequence++;
      replayUploadedBytes += bodyBytes;
      replayChunksInFlight++;
      send(replayUrl, body, {
        keepalive: preferKeepalive,
        reserveBytes: eventsKeepaliveReserveBytes,
        onResponse: /* @__PURE__ */ __name((response) => {
          const throttled = response?.status === 429;
          if (throttled) {
            replayThrottledChunks++;
            replayUploadedBytes -= bodyBytes;
            replayEventCount = Math.max(0, replayEventCount - count2);
          }
          settleReplayChunk();
          if (throttled || response && response.ok !== false) return;
          const marker = response?.headers?.get?.("x-lovable-events");
          const reason = marker === "unavailable" ? "upload_unavailable" : marker === "rejected" ? "upload_rejected" : "upload_failed";
          stopReplayRecording(reason, true);
        }, "onResponse"),
        onNetworkError: /* @__PURE__ */ __name(() => {
          stopReplayRecording("upload_failed", true);
          settleReplayChunk();
        }, "onNetworkError")
      });
      if (replayFinalized) return;
      if (replayChunkSequence - replayThrottledChunks >= maxReplayChunks) {
        endReplayOnSpentBudget("chunk_limit");
        return;
      }
    }
  }, "flushReplay");
  const scheduleReplayFlush = /* @__PURE__ */ __name(() => {
    if (replayFlushTimer) return;
    const setTimer = resolveSetTimer();
    if (!setTimer) {
      flushReplay();
      return;
    }
    replayFlushTimer = setTimer(flushReplay, replayFlushIntervalMs);
  }, "scheduleReplayFlush");
  const clearFlushTimer = /* @__PURE__ */ __name(() => {
    if (!flushTimer) return;
    const clearTimer = resolveClearTimer();
    if (clearTimer) clearTimer(flushTimer);
    flushTimer = null;
  }, "clearFlushTimer");
  const flush = /* @__PURE__ */ __name((unloading = false) => {
    clearFlushTimer();
    if (sendingDisabled || queue.length === 0) return;
    const events = queue.splice(0, batchSize);
    sendBatch(events, unloading || unloadingPage);
    if (queue.length > 0) scheduleFlush();
  }, "flush");
  const scheduleFlush = /* @__PURE__ */ __name(() => {
    if (flushTimer || sendingDisabled) return;
    const setTimer = resolveSetTimer();
    if (!setTimer) {
      flush();
      return;
    }
    flushTimer = setTimer(flush, 250);
  }, "scheduleFlush");
  const startEngagementSegment = /* @__PURE__ */ __name(() => {
    if (engagementSegmentStart === null) engagementSegmentStart = perf.now();
  }, "startEngagementSegment");
  const stopEngagementSegment = /* @__PURE__ */ __name(() => {
    engagementSegmentStart = null;
  }, "stopEngagementSegment");
  const clearEngagementTimer = /* @__PURE__ */ __name(() => {
    const clearTimer = resolveClearTimer();
    if (engagementTimer !== null && clearTimer) clearTimer(engagementTimer);
    engagementTimer = null;
  }, "clearEngagementTimer");
  const takeEngagementDelta = /* @__PURE__ */ __name(() => {
    if (engagementSegmentStart !== null) {
      const nowMs = perf.now();
      engagementAccruedMs += nowMs - engagementSegmentStart;
      engagementSegmentStart = nowMs;
    }
    const delta = Math.round(engagementAccruedMs);
    engagementAccruedMs = 0;
    return delta;
  }, "takeEngagementDelta");
  const emitEngagement = /* @__PURE__ */ __name((reason) => {
    const delta = takeEngagementDelta();
    if (delta <= 0) return;
    engagementReportedMs += delta;
    const capping = engagementReportedMs >= ENGAGEMENT_ACCRUAL_STOP_MS;
    if (capping) {
      engagementCapped = true;
      stopEngagementSegment();
      clearEngagementTimer();
    }
    enqueue("lovable.page_engagement", { reason: capping ? "capped" : reason, engagement_time_ms: delta });
  }, "emitEngagement");
  const scheduleEngagementEmit = /* @__PURE__ */ __name(() => {
    clearEngagementTimer();
    const setTimer = resolveSetTimer();
    if (!setTimer) return;
    const delay = ENGAGEMENT_EMIT_DELAYS_MS[Math.min(engagementEmitStep, ENGAGEMENT_EMIT_DELAYS_MS.length - 1)];
    engagementTimer = setTimer(() => {
      engagementEmitStep++;
      emitEngagement("threshold");
      if (engagementCapped) return;
      scheduleEngagementEmit();
    }, delay);
  }, "scheduleEngagementEmit");
  const clearUnfocusedTimer = /* @__PURE__ */ __name(() => {
    const clearTimer = resolveClearTimer();
    if (engagementUnfocusedTimer !== null) {
      if (clearTimer) clearTimer(engagementUnfocusedTimer);
      engagementUnfocusedSpentMs += Math.max(0, perf.now() - engagementUnfocusedArmedAt);
    }
    engagementUnfocusedTimer = null;
  }, "clearUnfocusedTimer");
  const resetUnfocusedGrace = /* @__PURE__ */ __name(() => {
    clearUnfocusedTimer();
    engagementUnfocusedSpentMs = 0;
  }, "resetUnfocusedGrace");
  const scheduleUnfocusedStop = /* @__PURE__ */ __name(() => {
    if (engagementUnfocusedTimer !== null) return;
    if (!d || d.visibilityState === "hidden" || d.hasFocus?.() !== false) return;
    const setTimer = resolveSetTimer();
    if (!setTimer) return;
    engagementUnfocusedArmedAt = perf.now();
    engagementUnfocusedTimer = setTimer(
      () => {
        engagementUnfocusedTimer = null;
        engagementUnfocusedSpentMs = ENGAGEMENT_UNFOCUSED_GRACE_MS;
        engagementStoppedUnfocused = true;
        emitEngagement("unfocused");
        stopEngagementSegment();
        clearEngagementTimer();
      },
      Math.max(0, ENGAGEMENT_UNFOCUSED_GRACE_MS - engagementUnfocusedSpentMs)
    );
  }, "scheduleUnfocusedStop");
  const resumeEngagementMeasurement = /* @__PURE__ */ __name(() => {
    if (d && d.visibilityState === "hidden") return;
    if (engagementStoppedUnfocused) return;
    if (engagementCapped) return;
    startEngagementSegment();
    engagementEmitStep = 0;
    scheduleEngagementEmit();
    scheduleUnfocusedStop();
  }, "resumeEngagementMeasurement");
  const rotatePageViewId = /* @__PURE__ */ __name(() => {
    emitEngagement("navigation");
    engagementReportedMs = 0;
    engagementCapped = false;
    resumeEngagementMeasurement();
    pageViewId = randomUuid();
    traceContext = createTraceContext();
    capturedClicks = 0;
    return pageViewId;
  }, "rotatePageViewId");
  const traceFieldsFor = /* @__PURE__ */ __name((eventName) => {
    if (eventName === "lovable.page_viewed") {
      return {
        trace_id: traceContext.traceId,
        span_id: traceContext.rootSpanId
      };
    }
    return {
      trace_id: traceContext.traceId,
      span_id: randomTraceHex(8),
      parent_span_id: traceContext.rootSpanId
    };
  }, "traceFieldsFor");
  const isErrorEventName = /* @__PURE__ */ __name((eventName) => eventName === "lovable.client_error" || eventName === "lovable.resource_error" || eventName === "lovable.replay_error", "isErrorEventName");
  const queueEvent = /* @__PURE__ */ __name((eventName, eventSchemaVersion, properties = {}) => {
    if (sendingDisabled) return null;
    if (isErrorEventName(eventName) && ++errorEventsSeen > maxErrorEventsPerPageLoad) {
      if (eventName === "lovable.client_error") markReplayCapturedByClientError(null);
      return null;
    }
    const flushNow = eventName === "lovable.client_error" && immediateErrorFlushes < maxImmediateErrorFlushes;
    if (flushNow) immediateErrorFlushes++;
    const eventId = randomUuid();
    const activeReplayId = replayId && !replayFinalized && (replayUploadEnabled || eventName === "lovable.client_error") ? replayId : null;
    const event = {
      event_id: eventId,
      event_name: eventName,
      event_schema_version: eventSchemaVersion,
      event_time: (/* @__PURE__ */ new Date()).toISOString(),
      session_id: sessionId,
      page_view_id: pageViewId,
      ...traceFieldsFor(eventName),
      properties
    };
    if (activeReplayId) event.replay_id = activeReplayId;
    if (flushNow) {
      queue.unshift(event);
    } else {
      queue.push(event);
    }
    if (eventName === "lovable.client_error") markReplayCapturedByClientError(eventId);
    if (flushNow || queue.length >= batchSize) {
      flush();
    } else {
      scheduleFlush();
    }
    return eventId;
  }, "queueEvent");
  const enqueue = /* @__PURE__ */ __name((eventName, properties = {}) => {
    const eventSchemaVersion = typeof eventName === "string" ? schemaVersionFor(eventName) : null;
    if (eventSchemaVersion === null) return null;
    return queueEvent(eventName, eventSchemaVersion, properties);
  }, "enqueue");
  let lastPageViewPath = loc.pathname;
  const track = /* @__PURE__ */ __name((eventName, properties = {}) => {
    if (eventName === "lovable.page_viewed") {
      rotatePageViewId();
      if (typeof properties.url_path === "string") lastPageViewPath = properties.url_path;
    }
    return enqueue(eventName, properties);
  }, "track");
  const pathFromUrl = /* @__PURE__ */ __name((value) => {
    try {
      return new URL(value, loc.href).pathname;
    } catch {
      return null;
    }
  }, "pathFromUrl");
  const hostFromUrl = /* @__PURE__ */ __name((value) => {
    try {
      return new URL(value, loc.href).host.replace(/^www\./iu, "");
    } catch {
      return null;
    }
  }, "hostFromUrl");
  const campaignKeys = [
    ["utm_source", "campaign_source"],
    ["utm_medium", "campaign_medium"],
    ["utm_campaign", "campaign_name"],
    ["utm_term", "campaign_term"],
    ["utm_content", "campaign_content"]
  ];
  const clickIDKeys = ["gclid", "dclid", "gbraid", "wbraid", "msclkid", "ttclid", "twclid", "li_fat_id", "fbclid"];
  const maxCampaignBytes = 128;
  const campaignPropertiesFrom = /* @__PURE__ */ __name((search) => {
    const properties = {};
    try {
      if (typeof search !== "string" || !search) return properties;
      const params = new URLSearchParams(search.replace(/;/gu, "&"));
      for (const [key, property] of campaignKeys) {
        const raw2 = params.get(key);
        if (typeof raw2 !== "string") continue;
        const value = raw2.trim();
        if (value && byteLength(value) <= maxCampaignBytes) properties[property] = value;
      }
      const present = clickIDKeys.filter((key) => {
        const raw2 = params.get(key);
        return typeof raw2 === "string" && raw2.trim() !== "";
      });
      if (present.length > 0) properties.campaign_click_id_types = present;
    } catch {
      return {};
    }
    return properties;
  }, "campaignPropertiesFrom");
  const truncateToJSONBytes = /* @__PURE__ */ __name((input, maxBytes) => {
    let result = input;
    while (result && byteLength(JSON.stringify(result)) > maxBytes) {
      result = result.slice(0, Math.floor(result.length * 0.8));
    }
    return result;
  }, "truncateToJSONBytes");
  const truncateToChars = /* @__PURE__ */ __name((value, maxChars) => {
    if (typeof value !== "string") return null;
    const collapsed = value.replace(/\s+/gu, " ").trim();
    if (!collapsed) return null;
    if (collapsed.length <= maxChars) return collapsed;
    const points = Array.from(collapsed);
    return points.length > maxChars ? points.slice(0, maxChars).join("") : collapsed;
  }, "truncateToChars");
  const urlPathMaxLength = 2048;
  const currentUrlPath = /* @__PURE__ */ __name(() => truncateToChars(loc.pathname || "/", urlPathMaxLength) || "/", "currentUrlPath");
  const serializeThrowable = /* @__PURE__ */ __name((value) => {
    const throwable = value && typeof value === "object" ? value : null;
    const stringifyPrimitive = /* @__PURE__ */ __name((input) => {
      if (typeof input === "string") return input;
      if (typeof input === "number" || typeof input === "boolean" || typeof input === "bigint") return String(input);
      return null;
    }, "stringifyPrimitive");
    const stack = stringifyPrimitive(throwable?.stack);
    const message3 = stringifyPrimitive(throwable?.message) ?? stringifyPrimitive(value) ?? "Unknown error";
    return {
      message: truncateToJSONBytes(message3.slice(0, 2e3), 2048),
      name: stringifyPrimitive(throwable?.name),
      stack: stack ? truncateToJSONBytes(stack.slice(0, 8e3), 8192) : null
    };
  }, "serializeThrowable");
  const quickReturnMs = 1e3;
  const loopWindowMs = 1e4;
  const loopQuickReturns = 10;
  const lastAtPath = /* @__PURE__ */ new Map();
  const quickReturnTimes = [];
  const markAtPath = /* @__PURE__ */ __name((path, now) => {
    for (const [seenPath, at] of lastAtPath) if (now - at >= quickReturnMs) lastAtPath.delete(seenPath);
    lastAtPath.set(path, now);
  }, "markAtPath");
  const emitPageView = /* @__PURE__ */ __name((navigationType, rotatePageView = true) => {
    if (rotatePageView) rotatePageViewId();
    const pagePath = loc.pathname;
    const properties = {
      url_path: pagePath,
      navigation_type: navigationType
    };
    if (typeof d?.referrer === "string" && d.referrer) {
      properties.referrer_host = hostFromUrl(d.referrer) ?? "";
      properties.referrer_path = pathFromUrl(d.referrer) ?? "";
    }
    Object.assign(properties, campaignPropertiesFrom(loc.search));
    lastPageViewPath = pagePath;
    markAtPath(pagePath, perf.now());
    enqueue("lovable.page_viewed", properties);
  }, "emitPageView");
  const emitPageViewIfPathChanged = /* @__PURE__ */ __name((navigationType) => {
    if (loc.pathname === lastPageViewPath) return;
    emitPageView(navigationType);
  }, "emitPageViewIfPathChanged");
  const emitReplaceStatePageView = /* @__PURE__ */ __name(() => {
    const path = loc.pathname;
    if (path === lastPageViewPath) return;
    const now = perf.now();
    const at = lastAtPath.get(path);
    if (at !== void 0 && now - at < quickReturnMs) {
      quickReturnTimes.push(now);
      if (quickReturnTimes.length > loopQuickReturns + 1) quickReturnTimes.shift();
      if (quickReturnTimes.length > loopQuickReturns && now - quickReturnTimes[0] < loopWindowMs) {
        lastPageViewPath = path;
        markAtPath(path, now);
        return;
      }
    }
    emitPageView("replace_state");
  }, "emitReplaceStatePageView");
  const startReplayRecording = /* @__PURE__ */ __name(() => {
    const record = replayMode === "rrweb" && isReplayRecordingAllowed && w.rrweb && typeof w.rrweb.record === "function" ? w.rrweb.record : null;
    if (!record || replayId) return;
    replayId = randomUuid();
    replayStartedAt = perf.now();
    replayFinalized = false;
    replayChunkSequence = 0;
    replayThrottledChunks = 0;
    replayChunksInFlight = 0;
    replayBudgetStopReason = null;
    replayUploadedBytes = 0;
    replayRecorderActive = false;
    replayHasFullSnapshot = false;
    replayUploadEnabled = isReplaySampledIn;
    replayCaptureReason = isReplaySampledIn ? "sampled" : null;
    replayTriggerEventId = null;
    replayTriggerEventName = null;
    replayCaptureMetadataEmitted = false;
    try {
      const stop = record({
        emit(event) {
          if (replayFinalized) return;
          if (!event || typeof event !== "object") return;
          if (replayDurationMs() >= maxReplayDurationMs) {
            stopReplayAtDurationLimit();
            return;
          }
          const eventType = replayEventType(event);
          if (!canSendReplayEvent(event)) {
            if (eventType === 2 && !replayHasFullSnapshot) {
              stopReplayRecording("full_snapshot_too_large", true);
            }
            return;
          }
          if (eventType === 3 && !replayHasFullSnapshot) return;
          if (eventType === 2) replayHasFullSnapshot = true;
          replayEventCount += 1;
          replayQueue.push(event);
          while (!replayUploadEnabled && replayQueue.length > maxReplayBufferedEvents) {
            const removableIndex = replayQueue.findIndex((queuedEvent) => replayEventType(queuedEvent) !== 2);
            replayQueue.splice(removableIndex >= 0 ? removableIndex : 0, 1);
            replayEventCount = Math.max(0, replayEventCount - 1);
          }
          if (emitReplayCaptureMetadataIfReady()) return;
          if (!replayUploadEnabled) return;
          if (replayQueue.length >= maxReplayEventsPerChunk) {
            flushReplay();
          } else {
            scheduleReplayFlush();
          }
        },
        blockClass: "rr-block",
        blockSelector: replayBlockSelector,
        collectFonts: false,
        ignoreClass: "rrweb-ignore",
        ignoreSelector: replayIgnoreSelector,
        inlineImages: false,
        maskAllInputs: true,
        maskInputFn: maskReplayText,
        maskInputOptions: {
          checkbox: false,
          color: false,
          date: true,
          "datetime-local": true,
          email: true,
          month: true,
          number: true,
          password: true,
          radio: false,
          range: false,
          search: true,
          select: true,
          tel: true,
          text: true,
          textarea: true,
          time: true,
          url: true,
          week: true
        },
        maskTextClass: "rr-mask",
        maskTextFn: maskReplayText,
        maskTextSelector: replayMaskTextSelector,
        recordAfter: "load",
        recordCanvas: false,
        recordCrossOriginIframes: false
      });
      if (replayFinalized) {
        if (typeof stop === "function") {
          try {
            stop();
          } catch {
          }
        }
        return;
      }
      replayRecorderActive = true;
      if (typeof stop === "function") stopReplayRecorder = stop;
      const setTimer = resolveSetTimer();
      if (setTimer && typeof record.takeFullSnapshot === "function") {
        setTimer(() => {
          if (!replayId || replayFinalized) return;
          try {
            record.takeFullSnapshot?.(false);
          } catch {
          }
        }, 1e3);
      }
      if (setTimer) {
        replayDurationTimer = setTimer(stopReplayAtDurationLimit, maxReplayDurationMs);
      }
      if (shouldEmitReplayLifecycleMetadata()) {
        emitReplayMetadata("started", "recorder_available");
      }
    } catch {
      if (replayId) {
        emitReplayMetadataOrErrorFor(
          replayId,
          "stopped",
          "recorder_start_failed",
          replayEventCount,
          replayDurationMs(),
          replayChunkSequence,
          replayUploadedBytes
        );
      }
      replayId = null;
      replayEventCount = 0;
      replayStartedAt = 0;
      replayFinalized = false;
      replayHasFullSnapshot = false;
      replayUploadEnabled = isReplaySampledIn;
      replayCaptureReason = isReplaySampledIn ? "sampled" : null;
      replayTriggerEventId = null;
      replayTriggerEventName = null;
      stopReplayRecorder = null;
      replayRecorderActive = false;
      clearReplayDurationTimer();
    }
  }, "startReplayRecording");
  const ensureReplayRecorder = /* @__PURE__ */ __name(() => {
    if (replayMode !== "rrweb" || !isReplayRecordingAllowed || replayId || replayRecorderLoading) return;
    if (w.rrweb && typeof w.rrweb.record === "function") {
      startReplayRecording();
      return;
    }
    const head = d?.head;
    if (!d?.createElement || !head?.appendChild) return;
    const recorderScript = d.createElement("script");
    replayRecorderLoading = true;
    recorderScript.async = true;
    recorderScript.src = replayScriptUrl;
    recorderScript.onload = () => {
      replayRecorderLoading = false;
      if (!w.rrweb || typeof w.rrweb.record !== "function") {
        emitReplayMetadataOrErrorFor(randomUuid(), "stopped", "recorder_script_failed", 0, 0, 0, 0);
        return;
      }
      startReplayRecording();
    };
    recorderScript.onerror = () => {
      replayRecorderLoading = false;
      emitReplayMetadataOrErrorFor(randomUuid(), "stopped", "recorder_script_failed", 0, 0, 0, 0);
    };
    head.appendChild(recorderScript);
  }, "ensureReplayRecorder");
  const finalizeReplayRecording = /* @__PURE__ */ __name((reason) => {
    if (!replayId || replayFinalized) return;
    stopReplayRecorderSafely();
    clearReplayDurationTimer();
    if (!replayHasFullSnapshot) {
      stopReplayRecording("missing_full_snapshot", true);
      return;
    }
    flushReplay(true);
    if (!replayFinalized) stopReplayRecording(reason);
  }, "finalizeReplayRecording");
  const stopReplayRecordingOnRuntimeError = /* @__PURE__ */ __name((event) => {
    if (!replayId || replayFinalized) return;
    const errorEvent = event && typeof event === "object" ? event : null;
    const errorRecord = errorEvent?.error && typeof errorEvent.error === "object" ? errorEvent.error : null;
    const filename = typeof errorEvent?.filename === "string" ? errorEvent.filename : "";
    const stack = typeof errorRecord?.stack === "string" ? errorRecord.stack : "";
    const isRecorderError = filename.includes("/__l5e/rrweb-record") || stack.includes("/__l5e/rrweb-record");
    if (isRecorderError) {
      stopReplayRecording("recorder_runtime_error", true);
    }
  }, "stopReplayRecordingOnRuntimeError");
  const webVitalRating = /* @__PURE__ */ __name((metric, value) => {
    const thresholds = {
      CLS: [0.1, 0.25],
      FCP: [1800, 3e3],
      INP: [200, 500],
      LCP: [2500, 4e3],
      TTFB: [800, 1800]
    };
    const threshold = thresholds[metric];
    if (!threshold) return "good";
    if (value <= threshold[0]) return "good";
    return value <= threshold[1] ? "needs-improvement" : "poor";
  }, "webVitalRating");
  const webVitalUnit = /* @__PURE__ */ __name((metric) => metric === "CLS" ? "score" : "millisecond", "webVitalUnit");
  const performanceEntryValue = /* @__PURE__ */ __name((entry, key) => {
    const value = entry[key];
    return typeof value === "number" && Number.isFinite(value) ? value : null;
  }, "performanceEntryValue");
  const observePerformanceEntries = /* @__PURE__ */ __name((entryType, callback) => {
    const ObserverCtor = w.PerformanceObserver;
    if (!ObserverCtor) return false;
    const supportedEntryTypes = ObserverCtor.supportedEntryTypes;
    if (Array.isArray(supportedEntryTypes) && !supportedEntryTypes.includes(entryType)) return false;
    try {
      const observer = new ObserverCtor((list) => {
        const entries = typeof list.getEntries === "function" ? list.getEntries() : [];
        for (const entry of entries) {
          if (entry && typeof entry === "object") callback(entry);
        }
      });
      observer.observe(
        entryType === "event" ? { type: entryType, buffered: true, durationThreshold: 40 } : { type: entryType, buffered: true }
      );
      return true;
    } catch {
      return false;
    }
  }, "observePerformanceEntries");
  const observeWebVitals = /* @__PURE__ */ __name(() => {
    const urlPath = currentUrlPath();
    const emitWebVital = /* @__PURE__ */ __name((metric, value, delta = value, id2 = randomUuid()) => {
      if (!Number.isFinite(value) || value < 0) return;
      enqueue("lovable.web_vital", {
        url_path: urlPath,
        metric,
        value,
        unit: webVitalUnit(metric),
        delta,
        rating: webVitalRating(metric, value),
        id: id2,
        navigation_type: "initial_load"
      });
    }, "emitWebVital");
    let fcpReported = false;
    let latestLcp = null;
    let clsValue = 0;
    let maxInp = 0;
    let finalized = false;
    const metricIds = {};
    const reportedValues = {};
    const metricId = /* @__PURE__ */ __name((metric) => {
      metricIds[metric] = metricIds[metric] || randomUuid();
      return metricIds[metric];
    }, "metricId");
    const reportMetric = /* @__PURE__ */ __name((metric, value) => {
      if (reportedValues[metric] === value) return;
      const previousValue = reportedValues[metric];
      reportedValues[metric] = value;
      emitWebVital(metric, value, previousValue === void 0 ? value : value - previousValue, metricId(metric));
    }, "reportMetric");
    const navigationEntries = typeof perf.getEntriesByType === "function" ? perf.getEntriesByType("navigation") : [];
    const navigationEntry = navigationEntries[0] && typeof navigationEntries[0] === "object" ? navigationEntries[0] : null;
    const responseStart = navigationEntry ? performanceEntryValue(navigationEntry, "responseStart") : null;
    const requestStart = navigationEntry ? performanceEntryValue(navigationEntry, "requestStart") : null;
    const fetchStart = navigationEntry ? performanceEntryValue(navigationEntry, "fetchStart") : null;
    const ttfbStart = requestStart ?? fetchStart;
    if (responseStart !== null && ttfbStart !== null && responseStart >= ttfbStart) {
      emitWebVital("TTFB", responseStart - ttfbStart);
    }
    observePerformanceEntries("paint", (entry) => {
      if (fcpReported || entry.name !== "first-contentful-paint") return;
      const startTime = performanceEntryValue(entry, "startTime");
      if (startTime === null) return;
      fcpReported = true;
      emitWebVital("FCP", startTime);
    });
    observePerformanceEntries("largest-contentful-paint", (entry) => {
      latestLcp = performanceEntryValue(entry, "startTime") ?? performanceEntryValue(entry, "renderTime") ?? performanceEntryValue(entry, "loadTime") ?? latestLcp;
    });
    const clsObserverStarted = observePerformanceEntries("layout-shift", (entry) => {
      if (entry.hadRecentInput === true) return;
      const value = performanceEntryValue(entry, "value");
      if (value !== null) clsValue += value;
    });
    observePerformanceEntries("event", (entry) => {
      const interactionId = performanceEntryValue(entry, "interactionId");
      if (interactionId === null || interactionId <= 0) return;
      const duration = performanceEntryValue(entry, "duration");
      if (duration !== null && duration > maxInp) maxInp = duration;
    });
    return (final = false) => {
      if (finalized) return;
      if (latestLcp !== null) reportMetric("LCP", latestLcp);
      if (clsObserverStarted) reportMetric("CLS", clsValue);
      if (maxInp > 0) reportMetric("INP", maxInp);
      if (final) finalized = true;
    };
  }, "observeWebVitals");
  const patchHistory = /* @__PURE__ */ __name((method, emitAfterCall) => {
    const historyObject = w.history;
    const original = historyObject && historyObject[method];
    if (!historyObject || typeof original !== "function") return;
    historyObject[method] = function(...args) {
      const result = original.apply(this, args);
      emitAfterCall();
      return result;
    };
  }, "patchHistory");
  const normalizeCaptureExceptionOptions = /* @__PURE__ */ __name((options) => {
    const record = options && typeof options === "object" && !Array.isArray(options) ? options : {};
    const mechanism = typeof record.mechanism === "string" ? record.mechanism : "manual";
    const severity = typeof record.severity === "string" ? record.severity : "error";
    return {
      mechanism: ["manual", "onerror", "unhandledrejection", "react_error_boundary"].includes(mechanism) ? mechanism : "manual",
      handled: typeof record.handled === "boolean" ? record.handled : true,
      severity: ["error", "warning", "info"].includes(severity) ? severity : "error"
    };
  }, "normalizeCaptureExceptionOptions");
  w.__lovableEvents = Object.assign(existing, {
    __userAppEventsSdkVersion: version,
    track,
    flush: /* @__PURE__ */ __name(() => flush(), "flush"),
    identify(identity) {
      const identityRecord = identity && typeof identity === "object" ? identity : null;
      appUserId = typeof identityRecord?.user_id === "string" ? identityRecord.user_id : null;
    },
    getIdentity() {
      return { app_user_id_hash_available: !!appUserId };
    },
    getReplay() {
      return {
        replay_id: replayId,
        active: !!replayId && !replayFinalized && replayRecorderActive,
        event_count: replayEventCount
      };
    },
    resetIdentity() {
      appUserId = null;
    },
    captureException(error, context = {}, options = {}) {
      const throwable = serializeThrowable(error);
      const captureOptions = normalizeCaptureExceptionOptions(options);
      let captureContext = context && typeof context === "object" && !Array.isArray(context) ? context : {};
      try {
        if (byteLength(JSON.stringify(captureContext)) > 4096) captureContext = {};
      } catch {
        captureContext = {};
      }
      enqueue("lovable.client_error", {
        occurrence_id: randomUuid(),
        ...throwable,
        ...captureOptions,
        context: captureContext
      });
    },
    startSpan(name, attributes = {}) {
      const startTime = (/* @__PURE__ */ new Date()).toISOString();
      const start = perf.now();
      return {
        end(status = "ok") {
          enqueue("lovable.frontend_span", {
            name,
            start_time: startTime,
            status,
            duration_ms: Math.max(0, perf.now() - start),
            attributes
          });
        }
      };
    }
  });
  if (w.addEventListener) {
    w.addEventListener("error", stopReplayRecordingOnRuntimeError, true);
  }
  ensureReplayRecorder();
  const finalizeWebVitals = observeWebVitals();
  if (w.addEventListener) {
    w.addEventListener(
      "error",
      (event) => {
        const errorEvent = event && typeof event === "object" ? event : null;
        const target = errorEvent?.target && typeof errorEvent.target === "object" ? errorEvent.target : null;
        let resourceUrl = null;
        if (target && target !== w) {
          if (typeof target.src === "string") {
            resourceUrl = target.src;
          } else if (typeof target.href === "string") {
            resourceUrl = target.href;
          }
        }
        if (resourceUrl !== null) {
          const resourceType = typeof target?.tagName === "string" ? target.tagName.toLowerCase() : "unknown";
          enqueue("lovable.resource_error", {
            resource_type: resourceType,
            url_host: hostFromUrl(resourceUrl) ?? "",
            failure_type: "load_error",
            element: resourceType,
            url_path: pathFromUrl(resourceUrl),
            mechanism: "resource_load",
            handled: false,
            severity: "error"
          });
          return;
        }
        const throwable = serializeThrowable(errorEvent?.error || errorEvent?.message);
        enqueue("lovable.client_error", {
          occurrence_id: randomUuid(),
          ...throwable,
          filename: typeof errorEvent?.filename === "string" ? pathFromUrl(errorEvent.filename) : null,
          lineno: typeof errorEvent?.lineno === "number" ? errorEvent.lineno : null,
          colno: typeof errorEvent?.colno === "number" ? errorEvent.colno : null,
          mechanism: "onerror",
          handled: false,
          severity: "error"
        });
      },
      true
    );
    w.addEventListener("unhandledrejection", (event) => {
      const rejectionEvent = event && typeof event === "object" ? event : null;
      const throwable = serializeThrowable(rejectionEvent?.reason);
      enqueue("lovable.client_error", {
        occurrence_id: randomUuid(),
        ...throwable,
        mechanism: "unhandledrejection",
        handled: false,
        severity: "error"
      });
    });
    w.addEventListener("pagehide", () => {
      unloadingPage = true;
      finalizeWebVitals(true);
      finalizeReplayRecording("pagehide");
      emitEngagement("pagehide");
      stopEngagementSegment();
      clearEngagementTimer();
      clearUnfocusedTimer();
      flush(true);
    });
    w.addEventListener("blur", () => scheduleUnfocusedStop());
    w.addEventListener("focus", () => {
      resetUnfocusedGrace();
      if (!engagementStoppedUnfocused) return;
      engagementStoppedUnfocused = false;
      resumeEngagementMeasurement();
    });
    w.addEventListener("pageshow", (event) => {
      const persisted = event && typeof event === "object" ? event.persisted : false;
      if (persisted === true) {
        unloadingPage = false;
        releaseBeaconBytes();
        resetUnfocusedGrace();
        engagementStoppedUnfocused = false;
        resumeEngagementMeasurement();
      }
    });
    w.addEventListener("popstate", () => emitPageViewIfPathChanged("popstate"));
    w.addEventListener("hashchange", () => emitPageViewIfPathChanged("hashchange"));
    if (autocaptureEnabled) {
      const labelMaxLength = 64;
      const tagMaxLength = 64;
      const ownTextMaxLength = 200;
      const chainMaxDepth = 32;
      const clickCapPerPageView = 200;
      const optOutMaxDepth = 512;
      const pathMaxDepth = 32;
      const pathMaxLength = 1024;
      const valueBearingTags = {
        select: true,
        textarea: true,
        input: true
      };
      const interactiveTags = {
        button: true,
        a: true,
        input: true,
        select: true,
        textarea: true,
        summary: true
      };
      const interactiveRoles = {
        button: true,
        link: true,
        menuitem: true,
        menuitemcheckbox: true,
        menuitemradio: true,
        tab: true,
        switch: true,
        checkbox: true,
        radio: true,
        option: true
      };
      const landmarkTags = {
        header: true,
        footer: true,
        main: true,
        nav: true,
        aside: true,
        section: true,
        article: true,
        form: true
      };
      const jsxSourceKey = typeof Symbol !== "undefined" && typeof Symbol.for === "function" ? /* @__PURE__ */ Symbol.for("__jsxSource__") : null;
      const asNode = /* @__PURE__ */ __name((value) => value && typeof value === "object" && typeof value.tagName === "string" ? value : null, "asNode");
      const knownTags = {};
      for (const tag of "html body div span main header footer nav aside section article form p a button input select textarea label fieldset legend optgroup option datalist output progress meter ul ol li dl dt dd table thead tbody tfoot tr td th caption col colgroup h1 h2 h3 h4 h5 h6 br hr pre blockquote figure figcaption small strong em b i u s q cite abbr code kbd samp var mark sub sup time address details summary dialog menu picture source track canvas iframe object embed param map area img video audio template slot noscript script style link meta title base head ins del ruby rt rp bdi bdo wbr data hgroup search fencedframe svg path g circle rect line polyline polygon ellipse text textpath tspan defs use symbol clippath mask pattern lineargradient radialgradient stop filter foreignobject marker image view desc animate animatetransform animatemotion set fegaussianblur feoffset feblend fecolormatrix fecomposite feflood femerge femergenode femorphology fetile feturbulence fedropshadow fedisplacementmap".split(" ")) {
        knownTags[tag] = true;
      }
      const knownRoles = {};
      for (const role of "button link menuitem menuitemcheckbox menuitemradio tab switch checkbox radio option combobox listbox textbox searchbox slider spinbutton treeitem gridcell row columnheader rowheader tooltip dialog alertdialog navigation main banner contentinfo complementary region form search article list listitem table grid tree menu menubar toolbar tabpanel tablist progressbar status alert log timer none presentation".split(" ")) {
        knownRoles[role] = true;
      }
      const knownInputTypes = {};
      for (const type of "button submit reset checkbox radio text password email number tel url search date time datetime-local month week color file range hidden image".split(" ")) {
        knownInputTypes[type] = true;
      }
      const knownAttrValue = /* @__PURE__ */ __name((value, vocabulary) => value !== null && vocabulary[value.toLowerCase()] === true ? value.toLowerCase() : null, "knownAttrValue");
      const tagOf = /* @__PURE__ */ __name((node) => {
        const tag = String(node.tagName).toLowerCase();
        return knownTags[tag] === true ? tag : "x";
      }, "tagOf");
      const attrOf = /* @__PURE__ */ __name((node, name) => {
        if (typeof node.getAttribute !== "function") return null;
        const value = node.getAttribute(name);
        return typeof value === "string" && value !== "" ? value : null;
      }, "attrOf");
      const hasAttr = /* @__PURE__ */ __name((node, name) => typeof node.getAttribute === "function" && typeof node.getAttribute(name) === "string", "hasAttr");
      const ownTextOf = /* @__PURE__ */ __name((node) => {
        if (valueBearingTags[tagOf(node)] === true) return null;
        const children = node.childNodes;
        if (!children || typeof children.length !== "number") return null;
        const list = children;
        let text = "";
        for (let index = 0; index < list.length; index++) {
          const child = list[index];
          if (child && child.nodeType === 3 && typeof child.nodeValue === "string") text += child.nodeValue;
          if (text.length > ownTextMaxLength) return null;
        }
        return text === "" ? null : text;
      }, "ownTextOf");
      const labelOf = /* @__PURE__ */ __name((node) => truncateToChars(
        attrOf(node, "aria-label") || attrOf(node, "title") || attrOf(node, "alt") || ownTextOf(node),
        labelMaxLength
      ), "labelOf");
      const nthOfType = /* @__PURE__ */ __name((parent, node, tag) => {
        const children = parent.children;
        if (!children || typeof children.length !== "number") return "";
        const list = children;
        let position = 0;
        let total = 0;
        for (let index = 0; index < list.length; index++) {
          const sibling = asNode(list[index]);
          if (!sibling || tagOf(sibling) !== tag) continue;
          total++;
          if (sibling === node) position = total;
        }
        return position > 0 ? ":" + position : "";
      }, "nthOfType");
      const pathOf = /* @__PURE__ */ __name((node) => {
        const segments = [];
        let current = node;
        for (let depth = 0; current && depth < pathMaxDepth; depth++) {
          const tag = tagOf(current);
          if (!tag || tag === "html") break;
          const parent = asNode(current.parentElement);
          segments.unshift(parent && tag !== "body" ? tag + nthOfType(parent, current, tag) : tag);
          if (tag === "body" || !parent) break;
          current = parent;
        }
        if (segments.length === 0) return null;
        let path = segments.join(">");
        while (path.length > pathMaxLength && segments.length > 1) {
          segments.shift();
          path = segments.join(">");
        }
        return path.length > pathMaxLength ? path.slice(path.length - pathMaxLength) : path;
      }, "pathOf");
      const componentNameOf = /* @__PURE__ */ __name((node) => {
        if (jsxSourceKey === null) return null;
        const source = node[jsxSourceKey];
        if (!source || typeof source !== "object") return null;
        const name = source.displayName;
        return typeof name === "string" && name !== "" ? name : null;
      }, "componentNameOf");
      const isInteractive = /* @__PURE__ */ __name((node) => {
        if (interactiveTags[tagOf(node)] === true) return true;
        const role = attrOf(node, "role");
        return role !== null && interactiveRoles[role.toLowerCase()] === true;
      }, "isInteractive");
      const chainFrom = /* @__PURE__ */ __name((event, maxDepth) => {
        const composed = typeof event.composedPath === "function" ? event.composedPath() : null;
        if (Array.isArray(composed)) {
          const nodes2 = [];
          for (const entry of composed) {
            if (nodes2.length >= maxDepth) return { nodes: nodes2, complete: false };
            const node2 = asNode(entry);
            if (node2) nodes2.push(node2);
          }
          return { nodes: nodes2, complete: true };
        }
        const nodes = [];
        let node = asNode(event.target);
        while (node) {
          if (nodes.length >= maxDepth) return { nodes, complete: false };
          nodes.push(node);
          node = asNode(node.parentElement);
        }
        return { nodes, complete: true };
      }, "chainFrom");
      const isPointerType = /* @__PURE__ */ __name((value) => value === "mouse" || value === "touch" || value === "pen", "isPointerType");
      const pointerTypeMaxAgeMs = 2e3;
      const forwardedClickMaxAgeMs = 300;
      let lastPointerType = "";
      let lastPointerAt = 0;
      const recentPointerType = /* @__PURE__ */ __name((maxAgeMs) => lastPointerType !== "" && perf.now() - lastPointerAt <= maxAgeMs ? lastPointerType : "", "recentPointerType");
      w.addEventListener(
        "pointerdown",
        (event) => {
          try {
            const pointerEvent = event;
            if (pointerEvent.isTrusted !== true) return;
            const pointerType = typeof pointerEvent.pointerType === "string" ? pointerEvent.pointerType : "";
            if (isPointerType(pointerType)) {
              lastPointerType = pointerType;
              lastPointerAt = perf.now();
            }
          } catch {
          }
        },
        true
      );
      const roundUnit = /* @__PURE__ */ __name((value) => Math.round(value * 1e3) / 1e3, "roundUnit");
      const numberOr = /* @__PURE__ */ __name((value) => typeof value === "number" && isFinite(value) ? value : null, "numberOr");
      w.addEventListener(
        "click",
        (event) => {
          try {
            if (!event || typeof event !== "object") return;
            const clickEvent = event;
            if (clickEvent.isTrusted !== true) return;
            if (capturedClicks >= clickCapPerPageView) return;
            const chain = chainFrom(clickEvent, optOutMaxDepth);
            if (!chain.complete) return;
            let element = null;
            let section = null;
            for (let depth = 0; depth < chain.nodes.length; depth++) {
              const node = chain.nodes[depth];
              if (hasAttr(node, "data-lov-no-capture")) return;
              if (depth >= chainMaxDepth) continue;
              if (element === null) {
                if (isInteractive(node)) element = node;
                continue;
              }
              if (section === null && landmarkTags[tagOf(node)] === true) section = node;
            }
            if (element === null) return;
            const pointerType = typeof clickEvent.pointerType === "string" ? clickEvent.pointerType : "";
            const detail = numberOr(clickEvent.detail) ?? 0;
            const forwarded = detail === 0 ? recentPointerType(forwardedClickMaxAgeMs) : "";
            const interactionType = isPointerType(pointerType) ? pointerType : forwarded || (detail === 0 ? "keyboard" : recentPointerType(pointerTypeMaxAgeMs) || "unknown");
            let offsetX = null;
            let offsetY = null;
            const clientX = numberOr(clickEvent.clientX);
            const clientY = numberOr(clickEvent.clientY);
            const rect = typeof element.getBoundingClientRect === "function" ? element.getBoundingClientRect() : null;
            if (interactionType !== "keyboard" && rect && clientX !== null && clientY !== null && rect.width > 0 && rect.height > 0) {
              offsetX = roundUnit(Math.min(1, Math.max(0, (clientX - rect.left) / rect.width)));
              offsetY = roundUnit(Math.min(1, Math.max(0, (clientY - rect.top) / rect.height)));
            }
            const viewport = w;
            enqueue("lovable.element_clicked", {
              // pathname only, and named url_path so the collector's path sanitizer
              // selects it as a second line of defence.
              url_path: currentUrlPath(),
              element_tag: tagOf(element),
              interaction_type: interactionType,
              element_role: knownAttrValue(attrOf(element, "role"), knownRoles),
              element_type: knownAttrValue(attrOf(element, "type"), knownInputTypes),
              element_label: labelOf(element),
              element_path: pathOf(element),
              component_name: truncateToChars(componentNameOf(element), tagMaxLength),
              section_tag: section ? truncateToChars(tagOf(section), tagMaxLength) : null,
              section_label: section ? truncateToChars(attrOf(section, "aria-label"), labelMaxLength) : null,
              offset_x: offsetX,
              offset_y: offsetY,
              viewport_width: numberOr(viewport.innerWidth),
              viewport_height: numberOr(viewport.innerHeight)
            });
            capturedClicks++;
          } catch {
          }
        },
        true
      );
    }
  }
  if (d && typeof d.addEventListener === "function") {
    d.addEventListener("visibilitychange", () => {
      if (d.visibilityState === "hidden") {
        unloadingPage = true;
        finalizeWebVitals();
        flushReplay(true);
        emitEngagement("hidden");
        stopEngagementSegment();
        clearEngagementTimer();
        clearUnfocusedTimer();
        flush(true);
        unloadingPage = false;
        return;
      }
      unloadingPage = false;
      releaseBeaconBytes();
      resumeEngagementMeasurement();
    });
  }
  patchHistory("pushState", () => emitPageViewIfPathChanged("push_state"));
  patchHistory("replaceState", emitReplaceStatePageView);
  enqueue("lovable.session_started", { reason: "new_session" });
  emitPageView("initial_load", false);
  resumeEngagementMeasurement();
})(window, "0.3.0-automated-flag", {"lovable.webmcp_tool_invoked":1,"lovable.session_started":1,"lovable.page_viewed":1,"lovable.client_error":1,"lovable.frontend_span":1,"lovable.interaction":1,"lovable.element_clicked":1,"lovable.form_submitted":1,"lovable.resource_error":1,"lovable.session_replay":1,"lovable.replay_error":1,"lovable.web_vital":1,"lovable.page_engagement":1}, 50, 51200, 524288, 100, 5242880, 50, 600000, 2000);})();